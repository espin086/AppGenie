### Code Implementation

Below is the Python code for a to-do application. This application will utilize OOP practices, argparse for command line arguments, and logging for capturing events. I'll include classes to manage tasks and a main function to tie everything together.

**Code:**

```python
import logging
from argparse import ArgumentParser
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class Task:
    """
    Represents a Task in the to-do application.
    
    Attributes:
        title (str): Title of the task.
        description (str): Description of the task.
        due_date (datetime): Due date of the task.
        completed (bool): Status of the task.
    """
    
    def __init__(self, title: str, description: str, due_date: datetime):
        """
        Initializes the Task with a title, description, and due date.
        
        Args:
            title (str): Title of the task.
            description (str): Description of the task.
            due_date (datetime): Due date of the task.
        """
        self.title = title
        self.description = description
        self.due_date = due_date
        self.completed = False

        logging.info(f"Task '{self.title}' created.")
        
    def mark_completed(self):
        """Marks the task as completed."""
        self.completed = True
        logging.info(f"Task '{self.title}' marked as completed.")
    
    def __str__(self):
        """String representation of the Task."""
        status = "Completed" if self.completed else "Pending"
        return f"Title: {self.title}, Description: {self.description}, Due: {self.due_date}, Status: {status}"

class ToDoApp:
    """
    Represents the To-Do application.
    
    Attributes:
        tasks (list): List of tasks in the to-do application.
    """
    
    def __init__(self):
        """Initializes the To-Do app with an empty list of tasks."""
        self.tasks = []
        logging.info("To-Do application initialized.")
        
    def add_task(self, task: Task):
        """Adds a task to the to-do list."""
        self.tasks.append(task)
        logging.info(f"Task '{task.title}' added to the to-do list.")
        
    def complete_task(self, title: str):
        """Marks a task as completed based on the title."""
        for task in self.tasks:
            if task.title == title:
                task.mark_completed()
                return
        logging.warning(f"Task '{title}' not found in the to-do list.")
    
    def display_tasks(self):
        """Displays all tasks in the to-do list."""
        for task in self.tasks:
            print(task)
        logging.info("Displayed all tasks.")

def main():
    parser = ArgumentParser(description="Simple To-Do Application")
    parser.add_argument("--title", type=str, required=True, help="Title of the task.")
    parser.add_argument("--description", type=str, required=True, help="Description of the task.")
    parser.add_argument("--due_date", type=str, required=True, help="Due date of the task in YYYY-MM-DD format.")
    parser.add_argument("--complete_task", type=str, help="Title of the task to mark as completed.")

    args = parser.parse_args()
    
    todo_app = ToDoApp()

    # Add task if task details are provided
    if args.title and args.description and args.due_date:
        due_date = datetime.strptime(args.due_date, "%Y-%m-%d")
        task = Task(args.title, args.description, due_date)
        todo_app.add_task(task)
    
    # Mark task as completed if title provided
    if args.complete_task:
        todo_app.complete_task(args.complete_task)
        
    # Display all tasks
    todo_app.display_tasks()
    
if __name__ == "__main__":
    main()
```

### Explanation:

1. **Task Class**:
   - Represents a task with attributes: title, description, due date, and completion status.
   - Methods include initialization, marking the task as completed, and string representation for easy display.

2. **ToDoApp Class**:
   - Manages a list of tasks.
   - Methods include adding a task, marking a task as completed, and displaying all tasks.

3. **Main Function**:
   - Uses argparse to accept command-line arguments for task details and completion.
   - Initializes the ToDoApp and adds tasks based on provided arguments.
   - Marks tasks as completed if specified.
   - Displays all tasks, showing their statuses.

### Diagram

Here is a UML Class Diagram showing the relationship between `Task` and `ToDoApp`, and a flowchart for the main function.

#### UML Class Diagram:

```plaintext
+--------------------------+          +----------------------+
|        ToDoApp           |          |         Task         |
+--------------------------+          +----------------------+
| - tasks: list            |          | - title: str         |
+--------------------------+          | - description: str   |
| + add_task(task: Task)   |<>------->| - due_date: datetime |
| + complete_task(title: str)     |          | - completed: bool    |
| + display_tasks()        |          +----------------------+
+--------------------------+          | + mark_completed()   |
                                       | + __str__()          |
                                       +----------------------+
```

#### Flowchart:

```mermaid
graph TD;
    A[Start] --> B[Parse Arguments]
    B --> C{Title, Description, Due Date Provided?}
    C -->|Yes| D[Create Task]
    D --> E[Add Task to ToDoApp]
    C -->|No| F
    E --> G
    F --> G{Complete Task Provided?}
    G -->|Yes| H[Complete Task in ToDoApp]
    G -->|No| I
    H --> I
    I --> J[Display All Tasks]
    J --> K[End]
```
### How the Code Works:

1. **Start**: Begin the program.
2. **Parse Arguments**: Use argparse to gather command-line arguments.
3. **Task Creation**: If a title, description, and due date are provided, create a new task.
4. **Add Task**: Add the newly created task to the ToDoApp.
5. **Complete Task**: If a task completion title is provided, mark the specified task as completed in ToDoApp.
6. **Display Tasks**: Display the list of all tasks and their statuses.
7. **End**: Terminate the program.

This To-Do application is easy to run and understand, utilizing object-oriented principles and providing clear logging to trace actions and states.