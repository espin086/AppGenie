"""Module for Data Processing and Model Training"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import logging
import argparse
from sklearn.metrics import mean_absolute_error as MAE
from sklearn.model_selection import train_test_split
from prophet import Prophet
from prophet.plot import add_changepoints_to_plot

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


class DataProcessor:
    """Class to handle Data Processing and Model Training"""

    def __init__(self, file_path):
        """
        Initializes the DataProcessor with a CSV file.

        Args:
            file_path (str): Path to the CSV file with data.
        """
        self.data = pd.read_csv(file_path)
        self.data['Date'] = pd.to_datetime(self.data['Date'])
        logging.info("Data initialized and Date column converted to datetime.")

    def prepare_data(self, feature_column, sample_date='06/30/2023'):
        """
        Prepares the data for training and testing.

        Args:
            feature_column (str): The column to use as the target variable.
            sample_date (str): The date to split the training and test sets.

        Returns:
            Tuple: Training and testing DataFrames.
        """
        data = self.data[['Date', feature_column]].rename(columns={'Date': 'ds', feature_column: 'y'})
        data_train = data[data['ds'] <= sample_date].reset_index(drop=True)
        data_test = data[data['ds'] > sample_date].reset_index(drop=True)
        logging.info(f"Data prepared for feature '{feature_column}' with sample date '{sample_date}'.")
        return data_train, data_test

    def plot_series(self, data, feature_column):
        """
        Plots the time series data.

        Args:
            data (DataFrame): DataFrame with the time series data.
            feature_column (str): The column to plot.

        Returns:
            None
        """
        plt.figure(figsize=(10, 8))
        plt.plot(data['Date'], data[feature_column])
        plt.title(feature_column, y=1.05)
        plt.show()
        logging.info(f"Time series plot generated for feature '{feature_column}'.")


class ModelTrainer:
    """Class to handle model training and evaluation"""

    def __init__(self, data_train, data_test):
        """
        Initializes the ModelTrainer with training and testing data.

        Args:
            data_train (pd.DataFrame): Training data.
            data_test (pd.DataFrame): Testing data.
        """
        self.data_train = data_train
        self.data_test = data_test
        self.model = Prophet()

    def fit_model(self):
        """Fits the Prophet model on the training data."""
        self.model.fit(self.data_train)
        logging.info("Model fitted on training data.")

    def make_predictions(self, periods=6):
        """
        Makes future predictions based on the model.

        Args:
            periods (int): Number of periods to predict into the future.

        Returns:
            pd.DataFrame: DataFrame with the forecast.
        """
        future = self.model.make_future_dataframe(periods=periods, freq='M')
        forecast = self.model.predict(future)
        logging.info(f"Made future predictions for {periods} periods.")
        return forecast

    def plot_forecast(self, forecast):
        """
        Plots the forecast.

        Args:
            forecast (pd.DataFrame): DataFrame with the forecast.

        Returns:
            None
        """
        fig = self.model.plot(forecast)
        plt.show()
        add_changepoints_to_plot(fig.gca(), self.model, forecast)
        logging.info("Forecast plot generated.")

    def evaluate_model(self, forecast):
        """
        Evaluates the model using MAE and MAPE.

        Args:
            forecast (pd.DataFrame): DataFrame with the forecast.

        Returns:
            dict: Dictionary with evaluation metrics.
        """
        actual = pd.concat([self.data_train, self.data_test]).set_index('ds')['y']
        forecast = forecast.set_index('ds')
        mae = MAE(actual, forecast['yhat'])
        mape = np.mean(np.abs((actual - forecast['yhat']) / actual)) * 100
        logging.info(f"Model evaluation completed. MAE: {mae:.2f}, MAPE: {mape:.2f}%")
        return {'MAE': mae, 'MAPE': mape}


def main():
    parser = argparse.ArgumentParser(description="Time Series Forecasting with Prophet")
    parser.add_argument("--csv_file", type=str, required=True, help="Path to the CSV file.")
    parser.add_argument("--feature_column", type=str, required=True, help="Column to forecast.")
    parser.add_argument("--sample_date", type=str, default='06/30/2023', help="Sample date to split data.")
    args = parser.parse_args()

    processor = DataProcessor(args.csv_file)
    data_train, data_test = processor.prepare_data(args.feature_column, args.sample_date)
    processor.plot_series(processor.data, args.feature_column)

    trainer = ModelTrainer(data_train, data_test)
    trainer.fit_model()
    forecast = trainer.make_predictions()
    trainer.plot_forecast(forecast)
    
    evaluation_metrics = trainer.evaluate_model(forecast)
    print(evaluation_metrics)


if __name__ == "__main__":
    main()